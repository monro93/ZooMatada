
package zoo;


public interface IMaritim {
    public void neda();
    
}
