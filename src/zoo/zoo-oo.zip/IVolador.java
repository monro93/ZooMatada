package zoo;

public interface IVolador {
    public void vola();
}
