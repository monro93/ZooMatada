package zoo;

public interface ITerrestre {
    public void corre();
}
