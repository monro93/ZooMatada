package zoo;

public interface IOvipar {
    public void posa_ous();
}
